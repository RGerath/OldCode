//Bob Gerath
//Operating Systems
//Assignment 05
//libA05.h header file - to declare values and functions used by inclusive software

//eliminate possibility of infinite inclusion loop
#ifndef __LIBA05_H
#define __LIBA05_H

//define functions from libA05
extern void f1(void);
extern void f2(char *);

#endif