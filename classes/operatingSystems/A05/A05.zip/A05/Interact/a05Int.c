//Bob Gerath
//Operating Systems
//Assignment 05
//Interact
//A simple program exercising the functionality of libA05.so

#include <stdio.h>
#include "libA05.h"

int main(int argc, char *argv[])
{
	f1();
	printf("This is a simple demonstration of a simple library:\n");
	f2("TEST STRING");
}