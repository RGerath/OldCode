//Bob Gerath
//Operating Systems
//Assignment 05
//Header file for the absolute function used by a05Exp.c

#ifndef __LIBABSOLUTE_H
#define __LIBABSOLUTE_H

extern int absolute(int);

#endif