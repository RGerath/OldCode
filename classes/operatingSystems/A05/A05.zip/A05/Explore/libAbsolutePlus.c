//Bob Gerath
//Operating Systems
//Assignment 05
//Source code for 'positive' implementation of absolute()

int absolute(int in)
{
	return(in);
}