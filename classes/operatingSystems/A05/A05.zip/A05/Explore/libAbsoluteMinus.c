//Bob Gerath
//Operating Systems
//Assignment 05
//Source code for 'negative' implementation of absolute()

int absolute(int in)
{
	return(-in);
}